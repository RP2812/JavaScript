
function startgame(){
// for dice1
    let dice1 = Math.floor((Math.random()*6)+1);
    let randomDice = "images/dice"+dice1+".png";
    document.querySelectorAll("div img")[0].setAttribute("src", randomDice);

// for dice2
    let dice2 = Math.floor((Math.random()*6)+1);
    let randomDice2 = "images/dice"+dice2+".png";
    if(dice1===dice2)
    {
        if(dice2===6)
        {
            dice2-=1
        }
        else
        {
            dice2 +=1
        }
    }
    document.querySelectorAll("div img")[1].setAttribute("src", randomDice2);
    if(dice1 > dice2)
    {
        document.querySelector("h2").innerHTML = "Player1 win";
    }
    else{
        document.querySelector("h2").innerHTML = "Computer Win";
    }
    
}

